import Data.List

file3 = lines <$> readFile "3_cods_sort.txt"
file4 = lines <$> readFile "4_cods_sort.txt"

estaSubDiv codigo = any (\cod4 -> codigo \\ cod4 == "")

main = do
        file3 <- lines <$> readFile "3_cods_sort.txt" 
        file4 <- lines <$> readFile "4_cods_sort.txt" 
        let total = filter (\p -> p) $ map (`estaSubDiv` file4) file3
            in print . length $ total
