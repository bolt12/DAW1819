var Tweet = require('../../models/tweet')

// Lista de eventos
module.exports.listar = () => {
    return Tweet
        .find()
        .exec()
}

// Devolve a informação de um evento
module.exports.consultar = tid => {
    return Tweet
        .findOne({_id: tid})
        .exec()
}

// Insere um novo tweet
module.exports.inserir = tweet => {
    return Tweet.create(tweet)
}


module.exports.insertLike = tid => {
    return Tweet
        .update({_id: tid},{ $inc: { __v: 1} })
        .exec()
}