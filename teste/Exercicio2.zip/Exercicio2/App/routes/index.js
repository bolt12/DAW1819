var express = require('express');
var router = express.Router();
var axios = require('axios')

/* GET home page. */
router.get('/', function(req, res, next) {
  axios.get('http://clav-test.di.uminho.pt/api/classes/nivel/1')
    .then(resposta => res.render('index', {classes: resposta.data}))
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('error', {error: erro, message: 'Erro ao carregar dados da BD.'})
    })
});

router.get('/c/:classe', function(req, res, next) {
  axios.get('http://clav-test.di.uminho.pt/api/classes/c'+req.params.classe)
    .then(resposta => { res.render('classe', {classe: resposta.data[0]}) })
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('error', {error: erro, message: 'Erro ao carregar dados da BD.'})
    })
});

router.get('/descendentes/:classe', function(req, res, next) {
  axios.get('http://clav-test.di.uminho.pt/api/classes/c'+req.params.classe+'/descendencia')
    .then(resposta => { res.render('descendente', {classes: resposta.data}) })
    .catch(erro => {
      console.log('Erro ao carregar dados da BD.')
      res.render('error', {error: erro, message: 'Erro ao carregar dados da BD.'})
    })
});
module.exports = router;