var mongoose = require('mongoose')
var Schema = mongoose.Schema


var TweetSchema = new Schema({
    texto: {type: String, required: true},
    autor: {type: String, required: true},
    hash: {type: String},
    gostos: {type: Number}
})

module.exports = mongoose.model('Tweet', TweetSchema, 'tweets') // Nome que se quer dar ao modelo, schema, coleção da BD