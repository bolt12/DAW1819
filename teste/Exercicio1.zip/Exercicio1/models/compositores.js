var mongoose = require('mongoose')
var Schema = mongoose.Schema


var CompositorSchema = new Schema({
    nome: {type: String, required: false},
    bio: {type: String, required: false},
    dataNasc: {type: String, required: true},
    dataObito: {type: String, required: false},
    periodo: {type: String, required: false},
})

module.exports = mongoose.model('Compositor', CompositorSchema, 'compositores') // Nome que se quer dar ao modelo, schema, coleção da BD