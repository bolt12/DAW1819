var express = require('express')
var router = express.Router()
var Compositor = require('../../controllers/api/compositor')

// API para os eventos

router.get('/', (req, res) => {
    const query = {...req.query};
    if (req.query.data) {
        delete query.data;
        query.dataNasc = {$gt: req.query.data};
    }
    Compositor.listar(query)
        .then(dados => res.jsonp(dados))
        .catch(erro => res.status(500).send('Erro na listagem de compositores.'))
})

router.get('/:id', (req, res) => {
    const { id } = req.params
    Compositor.consultar(id)
        .then(dados => res.jsonp(dados))
        .catch(erro => res.status(500).send('Erro na listagem de compositores.'))
})

module.exports = router