var Compositor = require('../../models/compositores')

// Lista de eventos
module.exports.listar = (query) => {
    return Compositor
        .find(query, {id:1, nome:1, dataNasc:1})
        .exec()
}

// Devolve a informação de um evento
module.exports.consultar = tid => {
    return Compositor
        .findOne({id: tid})
        .exec()
}

// Insere um novo compositor
module.exports.inserir = compositor => {
    return Compositor.create(compositor)
}